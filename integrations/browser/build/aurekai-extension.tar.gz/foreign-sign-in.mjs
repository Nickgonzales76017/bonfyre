// Shared Aurekai card. Account scope and provider admission stay in WebWork;
// the installed extension alone controls the real provider tab and companion.
import {encode,decode} from '../workspace-msgpack.mjs';
import {providerReview,sameProviderBinding} from '../provider-contract.mjs';
const el=(tag,text)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=String(text);return n;};
const check=(value,message)=>{if(!value)throw Error(message);};
const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const OWNER_RESPONSE_BYTES=512*1024;
const accessRefused=error=>error?.status===401||error?.status===403||error?.code==='binding_changed';
const nativeError=(message,status,code)=>Object.assign(Error(message),Number.isInteger(status)?{status,code}:code?{code}:{});
const requestId=()=>Array.from(crypto.getRandomValues(new Uint8Array(16)),n=>n.toString(16).padStart(2,'0')).join('');

async function nativePacket(operation,review,{request=fetch,signal,payload}={}){
 check(providerReview(review),'Choose an exact current native work card.');
 const query=new URLSearchParams({context:review.context,operation});if(operation==='get')query.set('job',review.jobId);
 const controller=new AbortController(),abort=()=>controller.abort(signal.reason),timer=setTimeout(()=>controller.abort(),15000);let bytes,reader;
 if(signal?.aborted){clearTimeout(timer);throw signal.reason||Error('The work card was closed.');}signal?.addEventListener('abort',abort,{once:true});
 try{
  if(payload)bytes=encode([1,payload]);
  const response=await request('/sources/_web?'+query,{method:payload?'POST':'GET',credentials:'same-origin',cache:'no-store',redirect:'error',headers:{Accept:'application/msgpack',...(payload?{'Content-Type':'application/msgpack'}:{})},body:bytes,signal:controller.signal});
  if(!response.ok){await response.body?.cancel();throw nativeError([401,403].includes(response.status)?'Current access to this destination was refused.':'The native provider owner is unavailable.',response.status);}
  const type=response.headers.get('content-type')?.split(';')[0].trim().toLowerCase(),length=response.headers.get('content-length');
  if(type!=='application/msgpack'||length!==null&&(!/^\d+$/.test(length)||Number(length)>OWNER_RESPONSE_BYTES)){await response.body?.cancel();throw Error('The native provider response is not a bounded MessagePack packet.');}
  reader=response.body?.getReader();check(reader,'The native provider response is empty.');const chunks=[];let size=0;
  for(;;){const part=await reader.read();if(part.done)break;size+=part.value.length;check(size<=OWNER_RESPONSE_BYTES,'The native provider response exceeds its limit.');chunks.push(part.value);}
  check(!controller.signal.aborted&&size>0,'The native provider read was interrupted.');const body=new Uint8Array(size);let at=0;for(const chunk of chunks){body.set(chunk,at);at+=chunk.length;}
  const packet=decode(body);check(Array.isArray(packet)&&packet.length===3&&packet[0]===1&&typeof packet[1]==='boolean'&&object(packet[2]),'The native provider response is incomplete.');
  if(!packet[1])throw nativeError(typeof packet[2].message==='string'?packet[2].message:'The native owner refused this operation.',packet[2].code==='forbidden'?403:undefined,packet[2].code);
  if(!sameProviderBinding(packet[2].binding,review.binding))throw nativeError('Your account or destination changed. Reopen the work card.',409,'binding_changed');return packet[2];
 }finally{bytes?.fill(0);if(payload&&Object.hasOwn(payload,'secret'))payload.secret='';clearTimeout(timer);signal?.removeEventListener('abort',abort);try{await reader?.cancel();}catch{}try{reader?.releaseLock();}catch{}}
}

export function createProviderContinuation({request=fetch,target=globalThis.window,timeoutMs=30000}={}){
 let disposed=false;const pending=new Map();
 function bridge(operation,review,{signal}={}){
  if(disposed)return Promise.reject(Error('The work card is closed.'));
  if(operation==='continue')check(providerReview(review),'Choose an exact native work card.');
  return new Promise((resolve,reject)=>{
   const id=requestId(),finish=(error,value)=>{const job=pending.get(id);if(!job)return;pending.delete(id);clearTimeout(job.timer);target.removeEventListener('aurekai:provider:reply',listener);signal?.removeEventListener('abort',abort);error?reject(error):resolve(value);};
   const abort=()=>finish(signal.reason||Error('This work card was closed.'));
   const listener=event=>{const value=event.detail;if(value?.requestId!==id)return;if(value.ok!==true){finish(nativeError(value.reason||'The native browser companion is unavailable.',value.status,value.code));return;}finish(null,value.result);};
   const timer=setTimeout(()=>finish(Error(operation==='continue'?'No browser acknowledgment arrived. Return to the native work before trying again.':'Install or reload the Aurekai browser companion to continue alongside the provider.')),operation==='capabilities'?1500:timeoutMs);
   pending.set(id,{timer,finish});target.addEventListener('aurekai:provider:reply',listener);signal?.addEventListener('abort',abort,{once:true});
   if(signal?.aborted){abort();return;}
   // Synchronous dispatch preserves the user's browser activation for the
   // isolated content script. There is no web-accessible runtime API.
   target.dispatchEvent(new CustomEvent('aurekai:provider:request',{detail:{requestId:id,operation,...review?{review}:{}}}));
  });
 }
 return {
  capabilities(options={}){return bridge('capabilities',undefined,options);},
  async status(review,{signal}={}){
   check(!disposed&&providerReview(review),'Choose an exact native work card.');
   const [job,status]=await Promise.all([nativePacket('get',review,{request,signal}),nativePacket('status',review,{request,signal})]);
   check(job.id===review.jobId&&job.revision===review.revision,'This run changed after review. Reopen its details.');
   const capability=job.providerContinuation;check(object(capability)&&typeof capability.canContinue==='boolean'&&typeof capability.canAdminister==='boolean'&&Array.isArray(capability.modes),'The native provider capability is incomplete.');
   const provider=status.providers?.find(p=>p.id===capability.provider?.id),canAdminister=capability.canAdminister&&status.canAdminister===true;
   let companion;try{companion=await bridge('capabilities',undefined,{signal});}catch(error){companion={available:false,reason:error.message};}
   return {binding:job.binding,capability,provider,configured:status.configured===true,canAdminister,companion};
  },
  async continue(review,{signal}={}){
   const result=await bridge('continue',review,{signal});
   check(result&&['provider_open','provider_focused'].includes(result.state)&&result.work?.id===review.jobId&&result.work?.revision===review.revision&&sameProviderBinding(result.binding,review.binding),'The browser acknowledgment belongs to another work review.');return result;
  },
  connect(review,provider,secret,{signal}={}){return nativePacket('connect',review,{request,signal,payload:{id:review.jobId,revision:review.revision,binding:{...review.binding},provider,secret}});},
  disconnect(review,provider,{signal}={}){return nativePacket('disconnect',review,{request,signal,payload:{id:review.jobId,revision:review.revision,binding:{...review.binding},provider}});},
  dispose(){if(disposed)return;for(const job of [...pending.values()])job.finish(Error('The work card was closed. No native work was canceled.'));target.dispatchEvent(new CustomEvent('aurekai:provider:request',{detail:{requestId:requestId(),operation:'clear'}}));disposed=true;}
 };
}

// Presentation for an existing credential or provider-page adapter.
// This module owns no connection, browser tab, account or secret store.
let sequence=0;
const bounded=(value,maximum,name)=>{if(typeof value!=='string'||!value.trim()||value.length>maximum||value.includes('\0'))throw Error('Provide a bounded '+name+'.');return value;};
const node=(tag,text)=>{const element=document.createElement(tag);if(text!==undefined)element.textContent=text;return element;};
export function foreignSignInFields(fields){
 if(!Array.isArray(fields)||fields.length>8)throw Error('Use at most eight declared fields.');
 const names=new Set();
 return fields.map(field=>{
  if(!field||Object.keys(field).some(key=>!['name','label','kind','required','maxLength','help'].includes(key))||!/^[a-z][a-z0-9_]{0,63}$/.test(field.name)||names.has(field.name))throw Error('Use unique declared field names without stored values.');
  names.add(field.name);const kind=field.kind??'secret',maxLength=field.maxLength??4094;
  if(!['secret','text'].includes(kind)||!Number.isInteger(maxLength)||maxLength<1||maxLength>4095||field.required!==undefined&&typeof field.required!=='boolean')throw Error('Use the declared field type and length.');
  if(field.help!==undefined&&(typeof field.help!=='string'||field.help.length>400))throw Error('Use a bounded field description.');
  return Object.freeze({name:field.name,label:bounded(field.label,120,'field label'),kind,required:field.required!==false,maxLength,help:field.help||''});
 });
}
function mountDeclaredSignInCard(host,options){
 const fields=foreignSignInFields(options.fields??[]),reviewKey=bounded(options.reviewKey,600,'review identity');
 const destination=bounded(options.destination,400,'destination'),title=bounded(options.title,160,'connection title');
 const openedMessage=options.openedMessage===undefined?'Continue sign-in on the provider page. Return here when it is finished.':bounded(options.openedMessage,600,'provider-page result');
 const address=new URL(options.origin);
 if(address.protocol!=='https:'||address.username||address.password||address.search||address.hash||address.pathname!=='/')throw Error('Name the exact HTTPS provider origin.');
 if(fields.length&&typeof options.onSubmit!=='function')throw Error('Declared fields need their existing credential adapter.');
 if(options.expanded!==undefined&&typeof options.expanded!=='boolean')throw Error('Use a boolean setup disclosure state.');
 const root=node('section');root.className='fsi-card';root.dataset.state='ready';root.dataset.expanded=String(options.expanded===true);
 const id='foreign-sign-in-'+(++sequence),heading=node('h3',title);heading.id=id;root.setAttribute('aria-labelledby',id);
 const head=node('header'),origin=node('p',address.origin),where=node('p',destination);origin.className='fsi-origin';where.className='fsi-destination';head.append(origin,heading,where);root.append(head);
 if(options.description){const description=node('p',bounded(options.description,600,'connection description'));description.className='fsi-description';root.append(description);}
 const form=node('form');form.className='fsi-form';form.autocomplete='off';
 const controls=[],inputs=new Map(),reveals=[];
 for(const field of fields){
  const label=node('label'),caption=node('span',field.label),row=node('div'),input=node('input');row.className='fsi-field-row';
  input.name=field.name;input.type=field.kind==='secret'?'password':'text';input.required=field.required;input.maxLength=field.maxLength;input.autocomplete='off';input.spellcheck=false;input.setAttribute('autocapitalize','none');
  input.setAttribute('aria-label',field.label);inputs.set(field.name,input);controls.push(input);row.append(input);
  if(field.kind==='secret'){const reveal=node('button','Show');reveal.type='button';reveal.className='fsi-reveal';reveal.setAttribute('aria-label','Show '+field.label);reveal.setAttribute('aria-pressed','false');reveal.onclick=()=>{if(locked())return;const show=input.type==='password';input.type=show?'text':'password';reveal.textContent=show?'Hide':'Show';reveal.setAttribute('aria-label',(show?'Hide ':'Show ')+field.label);reveal.setAttribute('aria-pressed',String(show));};controls.push(reveal);reveals.push({input,reveal,label:field.label});row.append(reveal);}
  label.append(caption,row);if(field.help)label.append(node('small',field.help));form.append(label);
 }
 const status=node('p',options.status||'');status.className='fsi-status';status.setAttribute('role','status');status.setAttribute('aria-live','polite');
 const actions=node('footer');actions.className='fsi-actions';
 let submit=null,open=null,expand=null;
 if(fields.length){submit=node('button',options.submitLabel||'Store credential');submit.type='submit';submit.className='fsi-primary';controls.push(submit);form.append(submit);root.append(form);}
 if(typeof options.onOpen==='function'){open=node('button',options.openLabel||'Continue on provider site');open.type='button';open.onclick=()=>run('open',options.onOpen);controls.push(open);actions.append(open);}
 const details=options.details||null;
 if(details){details.className=(details.className?details.className+' ':'')+'fsi-details';details.hidden=options.expanded!==true;details.id=id+'-details';expand=node('button',details.hidden?options.detailsLabel||'Expand setup details':'Collapse setup details');expand.type='button';expand.setAttribute('aria-controls',details.id);expand.setAttribute('aria-expanded',String(!details.hidden));expand.onclick=()=>{if(locked())return;const expanded=details.hidden;details.hidden=!expanded;root.dataset.expanded=String(expanded);expand.setAttribute('aria-expanded',String(expanded));expand.textContent=expanded?'Collapse setup details':options.detailsLabel||'Expand setup details';options.onExpandedChange?.(expanded);};controls.push(expand);actions.append(expand);}
 const dismiss=node('button','Not now');dismiss.type='button';dismiss.className='fsi-dismiss';dismiss.onclick=()=>pause();actions.append(dismiss);root.append(status,actions);if(details)root.append(details);
 let disposed=false,paused=false,pending=false,disabled=!!options.disabled,needsRead=false,serial=0,controller=null;
 const submissions=new Set();
 const alive=()=>!disposed&&root.isConnected!==false;
 const locked=()=>!alive()||paused||pending||disabled||needsRead;
 function clearFields(){for(const input of inputs.values())input.value='';for(const {input,reveal,label}of reveals){input.type='password';reveal.textContent='Show';reveal.setAttribute('aria-label','Show '+label);reveal.setAttribute('aria-pressed','false');}}
 function wipe(values){for(const key of Object.keys(values))values[key]='';}
 function controlState(){for(const control of controls)control.disabled=locked();if(details)details.inert=locked();dismiss.disabled=disposed||paused;root.setAttribute('aria-busy',String(pending));}
 async function run(kind,callback,values={}){
  if(locked()){wipe(values);return;}
  const ticket=++serial;controller=new AbortController();const signal=controller.signal;pending=true;submissions.add(values);clearFields();controlState();status.textContent=kind==='submit'?'Waiting for the native credential owner…':'Opening the provider page…';
  try{
   await callback(values,{reviewKey,signal});
   if(!alive()||ticket!==serial||signal.aborted)return;
   root.dataset.state=kind==='submit'?'stored':'provider-page';
   status.textContent=kind==='submit'?'Stored by the native owner. Provider access still needs verification.':openedMessage;
  }catch{
   if(!alive()||ticket!==serial||signal.aborted)return;
   needsRead=true;root.dataset.state='uncertain';status.textContent=kind==='submit'?'The credential outcome was not confirmed. Read the current owner status before trying again.':'The provider page could not be opened. Reload this setup before trying again.';
  }finally{wipe(values);submissions.delete(values);if(alive()&&ticket===serial){pending=false;controller=null;controlState();}}
 }
 form.onsubmit=event=>{event.preventDefault();if(locked()||!form.reportValidity())return;const values={};for(const field of fields){const value=inputs.get(field.name).value;if(new TextEncoder().encode(value).length>field.maxLength){status.textContent='The entered value exceeds its declared field limit.';clearFields();return;}values[field.name]=value;}return run('submit',options.onSubmit,values);};
 function pause(){if(disposed||paused)return;const wasPending=pending;serial++;controller?.abort();controller=null;pending=false;paused=true;clearFields();for(const values of submissions)wipe(values);form.hidden=true;if(details)details.hidden=true;if(expand)expand.setAttribute('aria-expanded','false');root.dataset.expanded='false';root.dataset.state='paused';status.textContent=wasPending?'This request may still finish. Read the current owner status before continuing.':'Connection entry closed. Reopen setup when you are ready.';controlState();options.onDismiss?.({reviewKey,pending:wasPending});}
 host.replaceChildren(root);controlState();
 return {
  element:root,
  setDisabled(value){if(disposed)return;disabled=!!value;controlState();},
  clear:clearFields,
  dismiss:pause,
  destroy(){if(disposed)return;disposed=true;serial++;controller?.abort();controller=null;clearFields();for(const values of submissions)wipe(values);submissions.clear();form.onsubmit=null;dismiss.onclick=null;if(open)open.onclick=null;if(expand)expand.onclick=null;for(const {reveal}of reveals)reveal.onclick=null;controlState();root.remove();},
 };
}

export function mountForeignSignIn(container,options={}){
 const stylesheet=new URL('./foreign-sign-in.css',import.meta.url).href;
 if(![...document.querySelectorAll('link[rel="stylesheet"]')].some(link=>link.href===stylesheet)){const style=el('link');style.rel='stylesheet';style.href=stylesheet;style.dataset.nativeProviderStyle='';document.head.append(style);}
 if(options.jobId===undefined)return mountDeclaredSignInCard(container,options);
 const {context,jobId,revision,capability,binding,onChange=()=>{},onAccessRefused=()=>{},adapter=createProviderContinuation()}=options;
 const review={context,jobId,revision,binding};check(container&&providerReview(review)&&capability?.canContinue===true,'The native owner has not admitted provider continuation.');
 const section=el('section');section.className='ak-provider-card';section.setAttribute('aria-label','Provider connection');
 const header=el('header'),title=el('h3',capability.provider.name),expand=el('button','Expand');expand.type='button';expand.setAttribute('aria-expanded','false');header.append(title,expand);
 const status=el('p','Checking this destination’s provider access…');status.setAttribute('role','status');
 const open=el('button','Open provider');open.type='button';open.disabled=true;open.dataset.nativeProviderContinue='';open.dataset.nativeProviderContext=context;open.dataset.nativeProviderJob=jobId;open.dataset.nativeProviderRevision=String(revision);
 const details=el('div');details.hidden=true;details.className='ak-provider-details';details.append(el('p','Sign-in, MFA and consent stay on the provider’s real site, beside the Aurekai browser companion. Returning here does not prove a connected API key.'));
 const connection=el('p'),form=el('form'),label=el('label',capability.provider.name+' API key'),input=el('input');input.type='password';input.autocomplete='off';input.spellcheck=false;input.maxLength=4095;input.minLength=8;input.required=true;input.setAttribute('aria-label',capability.provider.name+' API key');label.append(input);
 const save=el('button','Save API key');save.type='submit';const remove=el('button','Remove saved API key');remove.type='button';const refresh=el('button','Refresh connection');refresh.type='button';form.append(label,save);form.hidden=true;remove.hidden=true;details.append(connection,form,remove,refresh);section.append(header,status,open,details);container.replaceChildren(section);
 let destroyed=false,busy=false,current=null,uncertain=false;const controller=new AbortController();
 const refused=error=>{if(!accessRefused(error))return false;input.value='';current=null;onAccessRefused(error);return true;};
 const writable=()=>{const required=Array.isArray(current?.provider?.fields)?current.provider.fields.filter(f=>f.required):[];return current?.canAdminister===true&&current.configured&&current.capability.credentialInput==='native_api_key'&&current.provider?.declared===true&&required.length===1&&required[0].name==='api_key';};
 function controls(){const canWrite=writable()&&!uncertain&&!busy;open.disabled=busy||!current?.capability.canContinue||!current?.companion.available;save.disabled=input.disabled=!canWrite;remove.disabled=!canWrite;form.hidden=!writable();remove.hidden=!writable()||current.provider?.stored!==true;refresh.disabled=busy;}
 async function refreshState(){
  if(destroyed||busy)return;busy=true;controls();input.value='';
  try{const result=await adapter.status(review,{signal:controller.signal});if(destroyed)return;current=result;uncertain=false;connection.textContent=result.provider?.stored?'API key stored for this destination. Provider use is checked by an actual native run.':'No API key is stored for this destination.';
   status.textContent=!result.capability.canContinue?result.capability.reason:result.companion.available?'Continue in the provider tab with Aurekai alongside it.':result.companion.reason||'The Aurekai browser companion is unavailable.';
   if(!result.canAdminister)connection.append(' Current access permits viewing; a destination administrator manages this key.');
  }catch(error){if(!destroyed){current=null;refused(error);if(!destroyed){status.textContent=error.message;connection.textContent='Current connection state is unavailable.';}}}
  finally{if(!destroyed){busy=false;controls();}}
 }
 expand.addEventListener('click',()=>{details.hidden=!details.hidden;expand.textContent=details.hidden?'Expand':'Compact';expand.setAttribute('aria-expanded',String(!details.hidden));if(details.hidden)input.value='';});
 open.addEventListener('click',()=>{
  if(busy||destroyed||!current?.capability.canContinue||!current.companion.available)return;
  // Invoke before awaiting anything: the content script checks the actual click.
  const operation=adapter.continue(review,{signal:controller.signal});busy=true;controls();status.textContent='Checking native work and opening its provider…';
  operation.then(result=>{if(!destroyed)status.textContent=(result.state==='provider_focused'?'Returned to the same provider tab.':'Provider tab opened.')+(result.companion==='toolbar_required'?' Open Aurekai from Chrome’s toolbar to show the companion.':' Aurekai stays alongside it.');},error=>{if(!destroyed){refused(error);if(!destroyed)status.textContent=error.message;}}).finally(()=>{if(!destroyed){busy=false;controls();}});
 });
 async function change(clear){
  if(destroyed||busy||!writable()||uncertain)return;
  let secret=input.value;input.value='';busy=true;controls();status.textContent=clear?'Removing this destination’s stored key…':'Saving directly to the native credential owner…';
  try{const result=clear?await adapter.disconnect(review,capability.provider.id,{signal:controller.signal}):await adapter.connect(review,capability.provider.id,secret,{signal:controller.signal});secret='';if(destroyed)return;
   check(sameProviderBinding(result.binding,binding),'The destination changed during the credential operation.');const provider=result.providers?.find(p=>p.id===capability.provider.id);check(provider&&provider.stored===!clear,'The credential owner did not confirm the requested state.');
   current={...current,provider,configured:result.configured===true,canAdminister:result.canAdminister===true&&current.capability.canAdminister};connection.textContent=clear?'No API key is stored for this destination.':'API key stored. This does not assert provider verification or complete the run.';status.textContent=clear?'Native key removal confirmed.':'Native key storage confirmed.';onChange();
  }catch(error){secret='';if(!destroyed){uncertain=true;refused(error);if(!destroyed)status.textContent=error.message+' Refresh the native connection before another change.';}}
  finally{secret='';if(!destroyed){busy=false;controls();}}
 }
 form.addEventListener('submit',event=>{event.preventDefault();void change(false);});remove.addEventListener('click',()=>void change(true));refresh.addEventListener('click',()=>void refreshState());
 void refreshState();return {dispose(){if(destroyed)return;destroyed=true;input.value='';current=null;controller.abort();adapter.dispose();section.remove();}};
}
